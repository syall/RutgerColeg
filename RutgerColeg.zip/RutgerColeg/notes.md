# Title Screen  
* Press to Start 
* "Deep fry" RutgerColeg

# Menu Screen
* New Game
* Continue
* Settings - Useless
* Airhorns/Call of Duty hit marker sound

# Character Customizer
* Has a lot of options, all except one combination is "greyed out"
* Boy and Girl
* Name
* Major
* Year
* School
* After, it will create an RUID
* Stats - Base(randomize for each major) + 50 you can allocate
  * Strength
  * Intelligence
  * Vitality
  * Dexterity
  * Charm
  
# Level Menu
* Looks like there will a levels, butonly one option
* Question marks on all the blocks
* WebReg

# Game Level
* Go out of generic high school
* Walk across screen
* Pass all Colegs
  * When pass by, door will close (REJECTED)
  * Only Rutger will have the door open
  * Jump (pay more after)
* Each attack debuffs or nullifies stats
 
# Level Complete Screen
* Pay Tuition
* Slow tilting R comes out of the black
* Scrolls larger and larger as "Banks of the Raritan" plays
* Pay Tuition again (RutgerColeg paypal)
